#if defined(__cplusplus)
extern "C" {
#endif

#include "heap/heap.h"

#if defined(__cplusplus)
}
#endif
